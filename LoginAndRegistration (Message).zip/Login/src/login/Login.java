package login;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Login {

    private String username;
    private String password;
    private String cellPhoneNumber;
    private static List<Login> registeredUsers = new ArrayList<>();

    public Login() {
        // Default constructor
    }

    public Login(String username, String password, String cellPhoneNumber) {
        this.username = username;
        this.password = password;
        this.cellPhoneNumber = cellPhoneNumber;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    // Method checking if username is correctly formatted
    public boolean checkUserName() {
        return username != null && username.contains("_") && username.length() <= 5;
    }

    // Method to check if the password meets complexity rules
    public boolean checkPasswordComplexity() {
        if (password == null || password.length() < 8) {
            return false;
        }
        boolean hasCapital = false;
        boolean hasNumber = false;
        boolean hasSpecial = false;
        String specialCharacters = "!@#$%^&*()_+=-`~[]\\{}|;':\",./<>?";

        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) {
                hasCapital = true;
            } else if (Character.isDigit(c)) {
                hasNumber = true;
            } else if (specialCharacters.contains(String.valueOf(c))) {
                hasSpecial = true;
            }
        }
        return hasCapital && hasNumber && hasSpecial;
    }

    // Method checking if cell phone number is correctly formatted
    public boolean checkCellPhoneNumber() {
        // Expression checking international country code and total length of up to 13 characters 
        String regex = "^\\+\\d{1,12}$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(cellPhoneNumber);
        return matcher.matches() && cellPhoneNumber.length() <= 13;
    }

    // Method to register a new user
    public String registerUser() {
        if (!checkUserName()) {
            return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.";
        }
        if (!checkPasswordComplexity()) {
            return "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        }
        if (!checkCellPhoneNumber()) {
            return "Cell phone number incorrectly formatted or does not contain international code.";
        }

        // If all checks pass, register user
        registeredUsers.add(this);
        return "Account successfully created.";
    }

    // Method to log in user
    public boolean loginUser(String loginUsername, String loginPassword) {
        for (Login user : registeredUsers) {
            if (user.getUsername().equals(loginUsername) && user.getPassword().equals(loginPassword)) {
                // For this basic example, we don't have first and last names stored.
                // A more complete system would include these.
                System.out.println("Welcome " + loginUsername + ", it is great to see you again.");
                return true;
            }
        }
        System.out.println("Username or password incorrect, please try again.");
        return false;
    }

    // Method returning login status message 
    public String returnLoginStatus(String loginUsername, String loginPassword) {
        for (Login user : registeredUsers) {
            if (user.getUsername().equals(loginUsername) && user.getPassword().equals(loginPassword)) {
                return "Welcome " + loginUsername + ", it is great to see you again.";
            }
        }
        return "Username or password incorrect, please try again.";
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Login user = new Login();

        System.out.println("Welcome to the Registration and Login System!");

        // Registration
        System.out.println("\n--- Registration ---");
        System.out.print("Enter your username: ");
        String newUsername = scanner.nextLine();
        System.out.print("Enter your password: ");
        String newPassword = scanner.nextLine();
        System.out.print("Enter your South African cell phone number (e.g., +27XXXXXXXXX): ");
        String newCellNumber = scanner.nextLine();

        user = new Login(newUsername, newPassword, newCellNumber);
        System.out.println(user.registerUser());

        // Login
        System.out.println("\n--- Login ---");
        System.out.print("Enter your username to log in: ");
        String loginUsername = scanner.nextLine();
        System.out.print("Enter your password to log in: ");
        String loginPassword = scanner.nextLine();

        user.loginUser(loginUsername, loginPassword);

        scanner.close();
    }
}   
        
    
    

