/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author RC_Student_lab
 */
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class Message {
    

    private String messageID;
    private int numMessagesSent;
    private String recipient;
    private String messageText;
    private String messageHash;

    private static int messageCounter = 0; // Keeps track of total messages sent
    private static List<Message> sentMessages = new ArrayList<>(); // Store sent messages

    public Message(String recipient, String messageText) {
        messageCounter++;
        this.numMessagesSent = messageCounter; // Auto-generate message number
        this.messageID = generateMessageID(); // Auto-generate message ID
        this.recipient = recipient;
        this.messageText = messageText;
        this.messageHash = createMessageHash(); // Auto-generate message hash
    }

    // Method to generate a 10-digit message ID
    private String generateMessageID() {
        Random random = new Random();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            sb.append(random.nextInt(10)); // Append a random digit (0-9)
        }
        return sb.toString();
    }

    // Method to create the message hash
    private String createMessageHash() {
        if (messageID == null || messageText == null || messageText.isEmpty()) {
            return "INVALID_HASH"; // Handle potential errors
        }
        String[] words = messageText.split("\\s+"); // Split by spaces
        String firstWord = words[0].toUpperCase();
        String lastWord = words[words.length - 1].toUpperCase();
        return messageID.substring(0, 2) + ":" + numMessagesSent + ":" + firstWord + lastWord;
    }

    // Method to check if the message text is too long
    public boolean checkMessageLength() {
        return messageText.length() <= 250;
    }

    // Method to check if the recipient cell number is valid
    public boolean checkRecipientCell() {
        // Simplified: Checks if it starts with '+' and has at least 4 digits after
        return recipient != null && recipient.startsWith("+") && recipient.length() >= 5;
    }

    // Method to handle sending, disregarding, or storing a message (Simplified)
    public String sendMessageAction() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Options: (1) Send Message, (2) Disregard, (3) Store");
        int choice = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        switch (choice) {
            case 1:
                sentMessages.add(this); // Store in the list
                return "Message sent";
            case 2:
                return "Message discarded";
            case 3:
                return "Message stored (not fully implemented)"; // Placeholder
            default:
                return "Invalid option";
        }
    }

    // Method to display message details
    public void displayMessageDetails() {
        System.out.println("Message ID: " + messageID);
        System.out.println("Message Hash: " + messageHash);
        System.out.println("Recipient: " + recipient);
        System.out.println("Message: " + messageText);
    }

    // Method to return a list of all sent messages
    public static List<Message> getSentMessages() {
        return sentMessages;
    }

    // Method to return the total number of messages sent
    public static int getTotalMessagesSent() {
        return messageCounter;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Welcome to QuickChat!");

        // Get the number of messages the user wants to enter
        System.out.print("How many messages do you want to enter? ");
        int numMessages = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        // Loop to get each message
        for (int i = 0; i < numMessages; i++) {
            System.out.println("\n--- Message " + (i + 1) + " ---");
            System.out.print("Recipient Number: ");
            String recipient = scanner.nextLine();
            System.out.print("Message (max 250 chars): ");
            String messageText = scanner.nextLine();

            Message currentMessage = new Message(recipient, messageText);

            if (!currentMessage.checkMessageLength()) {
                System.out.println("Please enter a message of less than 250 characters.");
                continue; // Skip to the next message
            }

            if (!currentMessage.checkRecipientCell()) {
                System.out.println("Cell phone number is incorrectly formatted. Please correct the number and try again.");
                continue; // Skip to the next message
            }

            String actionResult = currentMessage.sendMessageAction();
            System.out.println(actionResult);

            if (actionResult.equals("Message sent")) {
                currentMessage.displayMessageDetails();
            }
        }

        System.out.println("\nTotal messages sent: " + Message.getTotalMessagesSent());
        scanner.close();
    }
}    
    

